package com.example.mubu.service;

import com.example.mubu.client.GeminiClient;
import com.example.mubu.dto.ai.GeminiAnalyzeResult;
import com.example.mubu.dto.gemini.*;
import org.springframework.stereotype.Service;

import java.util.List;

// Gemini 기반 이미지 분석 서비스
@Service
public class AiAnalyzeService {

    private final GeminiClient geminiClient;
    private final GeminiRequestFactory geminiRequestFactory;

    public AiAnalyzeService(
            GeminiClient geminiClient,
            GeminiRequestFactory geminiRequestFactory
    ) {
        this.geminiClient = geminiClient;
        this.geminiRequestFactory = geminiRequestFactory;
    }

    // 이미지 기반 상품명 + (가능하다면) 현지 가격/통화 정보 추출
    public GeminiAnalyzeResult analyze(
            byte[] imageBytes,
            String mimeType
    ) {

        // 가격 비교용 고정 프롬프트
        // - 상품명은 검색에 적합한 한 줄 텍스트
        // - 텍스트 안에 현지 가격/통화까지 함께 포함해 달라고 요청
        String prompt = """
        이 이미지에 나온 상품에 대해 다음 정보를 알려줘.

        1) 브랜드명과 정확한 상품명을 검색에 적합한 한 줄 텍스트로 만들어줘.
        2) 상품 근처에 가격표가 있다면, 그 가격과 통화 코드를 함께 텍스트 안에 포함해줘.
           예시: "Sausage Cheese Sandwich 27 THB"
        3) 한국어/영어 표기가 섞여 있어도 괜찮지만, 숫자와 통화 코드는 반드시 남겨줘.
        4) 불필요한 설명 문장은 최대한 줄이고, 한 줄 또는 두 줄 이내로 간결하게 답변해줘.
        """;

        // Gemini 요청 DTO 생성
        GeminiRequest request =
                geminiRequestFactory.create(
                        prompt,
                        imageBytes,
                        mimeType
                );

        // Gemini API 호출
        GeminiResponse response =
                geminiClient.generateContent(
                        "gemini-2.0-flash",
                        request
                );

        // 서비스용 결과로 변환
        return GeminiAnalyzeResult.from(response);
    }
}
